var searchData=
[
  ['g_5fcurrent_5ffloor',['g_current_floor',['../globals_8h.html#a128ab70c77672ac0c3f503bfd2fcc1e4',1,'globals.c']]],
  ['g_5fdoor_5ftimer',['g_door_timer',['../globals_8h.html#a15cba84aeb460cd3c717e4c16aac2100',1,'globals.c']]],
  ['g_5flast_5fvalid_5ffloor',['g_last_valid_floor',['../globals_8h.html#a6158dca30e5b5277757fb2f38468ac7d',1,'globals.c']]],
  ['g_5fprevious_5ffloor',['g_previous_floor',['../globals_8h.html#abf0366bff5ffe71dfdeb4b11069f682f',1,'globals.c']]],
  ['g_5fprevious_5fstate',['g_previous_state',['../globals_8h.html#a92de634e93119c67bf2966659b127d1d',1,'globals.c']]],
  ['g_5fqueue',['g_queue',['../globals_8h.html#a437a5b6b88c412869f6e131c015f7908',1,'globals.c']]],
  ['g_5fstate',['g_state',['../globals_8h.html#a1668d1c33d3d6975bc189ec891262178',1,'globals.c']]]
];

var searchData=
[
  ['g_5fcurrent_5ffloor',['g_current_floor',['../globals_8h.html#a128ab70c77672ac0c3f503bfd2fcc1e4',1,'globals.c']]],
  ['g_5fdoor_5ftimer',['g_door_timer',['../globals_8h.html#a15cba84aeb460cd3c717e4c16aac2100',1,'globals.c']]],
  ['g_5flast_5fvalid_5ffloor',['g_last_valid_floor',['../globals_8h.html#a6158dca30e5b5277757fb2f38468ac7d',1,'globals.c']]],
  ['g_5fprevious_5ffloor',['g_previous_floor',['../globals_8h.html#abf0366bff5ffe71dfdeb4b11069f682f',1,'globals.c']]],
  ['g_5fprevious_5fstate',['g_previous_state',['../globals_8h.html#a92de634e93119c67bf2966659b127d1d',1,'globals.c']]],
  ['g_5fqueue',['g_queue',['../globals_8h.html#a437a5b6b88c412869f6e131c015f7908',1,'globals.c']]],
  ['g_5fstate',['g_state',['../globals_8h.html#a1668d1c33d3d6975bc189ec891262178',1,'globals.c']]],
  ['globals_2eh',['globals.h',['../globals_8h.html',1,'']]],
  ['globals_5fcheck_5ffor_5ffloor',['globals_check_for_floor',['../globals_8h.html#a078fc9fb0a8761b4c0dd95f11478c3f1',1,'globals.c']]],
  ['globals_5fupdate_5fcurrent_5ffloor',['globals_update_current_floor',['../globals_8h.html#a2c452af3ccbe40c1a7414abee51cf87a',1,'globals.c']]],
  ['globals_5fupdate_5fprevious_5ffloor',['globals_update_previous_floor',['../globals_8h.html#a54f2a692cc4a1aef70c1c535f17512a7',1,'globals.c']]]
];

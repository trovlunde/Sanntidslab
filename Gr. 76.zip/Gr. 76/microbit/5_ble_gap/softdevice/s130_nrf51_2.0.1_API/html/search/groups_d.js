var searchData=
[
  ['vendor_20specific_20uuid_20counts',['Vendor Specific UUID counts',['../group__BLE__UUID__VS__COUNTS.html',1,'']]],
  ['variables',['Variables',['../group__NRF__NVIC__VARIABLES.html',1,'']]]
];

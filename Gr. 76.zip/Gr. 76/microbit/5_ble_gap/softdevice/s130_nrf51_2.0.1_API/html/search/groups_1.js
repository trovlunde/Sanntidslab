var searchData=
[
  ['bluetooth_20appearance_20values',['Bluetooth Appearance values',['../group__BLE__APPEARANCES.html',1,'']]],
  ['ble_20softdevice_20common',['BLE SoftDevice Common',['../group__BLE__COMMON.html',1,'']]],
  ['ble_20connection_20handles',['BLE Connection Handles',['../group__BLE__CONN__HANDLES.html',1,'']]],
  ['bluetooth_20status_20codes',['Bluetooth status codes',['../group__BLE__HCI__STATUS__CODES.html',1,'']]]
];

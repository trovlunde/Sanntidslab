var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwx",
  1: "bns",
  2: "s",
  3: "_abcdefghiklmnoprstuvwx",
  4: "ns",
  5: "bn",
  6: "bns",
  7: "abcdefglmpstuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules"
};


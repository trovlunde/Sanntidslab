var searchData=
[
  ['logical_20link_20control_20and_20adaptation_20protocol_20_28l2cap_29',['Logical Link Control and Adaptation Protocol (L2CAP)',['../group__BLE__L2CAP.html',1,'']]]
];

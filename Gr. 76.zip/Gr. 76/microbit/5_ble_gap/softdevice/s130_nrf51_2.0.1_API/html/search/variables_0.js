var searchData=
[
  ['_5f_5fcr_5fflag',['__cr_flag',['../structnrf__nvic__state__t.html#ab98e73a38a7559b6b1b6ed52604603d4',1,'nrf_nvic_state_t']]],
  ['_5f_5firq_5fmasks',['__irq_masks',['../structnrf__nvic__state__t.html#a9dd5c67f6cb24a92e1c3f71769047cca',1,'nrf_nvic_state_t']]]
];

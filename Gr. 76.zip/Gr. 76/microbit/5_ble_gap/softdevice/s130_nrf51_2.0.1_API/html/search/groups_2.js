var searchData=
[
  ['characteristic_20presentation_20formats',['Characteristic Presentation Formats',['../group__BLE__GATT__CPF__FORMATS.html',1,'']]],
  ['common_20types_20and_20macro_20definitions',['Common types and macro definitions',['../group__ble__types.html',1,'']]],
  ['clock_20accuracy',['Clock accuracy',['../group__NRF__CLOCK__LF__XTAL__ACCURACY.html',1,'']]]
];

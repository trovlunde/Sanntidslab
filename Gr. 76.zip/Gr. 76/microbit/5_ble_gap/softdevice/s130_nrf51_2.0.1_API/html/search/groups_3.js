var searchData=
[
  ['defines',['Defines',['../group__BLE__COMMON__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__BLE__GAP__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__BLE__GATT__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__BLE__GATTC__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__BLE__GATTS__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__BLE__L2CAP__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__BLE__TYPES__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__NRF__MBR__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__NRF__NVIC__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__NRF__SDM__DEFINES.html',1,'']]],
  ['defines',['Defines',['../group__NRF__SOC__DEFINES.html',1,'']]]
];

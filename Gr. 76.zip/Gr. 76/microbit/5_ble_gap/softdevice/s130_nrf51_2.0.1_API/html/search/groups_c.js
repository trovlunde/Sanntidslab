var searchData=
[
  ['user_20memory_20types',['User Memory Types',['../group__BLE__USER__MEM__TYPES.html',1,'']]]
];

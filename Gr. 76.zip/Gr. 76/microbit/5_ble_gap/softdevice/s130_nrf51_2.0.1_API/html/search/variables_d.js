var searchData=
[
  ['name_5fspace',['name_space',['../structble__gatts__char__pf__t.html#a279e1e8de47b628414382aed4cec3c68',1,'ble_gatts_char_pf_t']]],
  ['normal',['normal',['../structnrf__radio__request__t.html#a140d30391ab57e9fbd4e98536d687e09',1,'nrf_radio_request_t']]],
  ['notify',['notify',['../structble__gatt__char__props__t.html#a9dd91c1e55995665ef09ec4c5bd5eaf7',1,'ble_gatt_char_props_t']]],
  ['nrf_5fnvic_5fstate',['nrf_nvic_state',['../group__NRF__NVIC__VARIABLES.html#gae5ad2c570afdfbdd77336aec4e6097a7',1,'nrf_nvic.h']]]
];

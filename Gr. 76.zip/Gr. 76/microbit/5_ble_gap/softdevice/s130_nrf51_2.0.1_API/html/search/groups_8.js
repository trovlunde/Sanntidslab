var searchData=
[
  ['module_20specific_20error_20code_20subranges',['Module specific error code subranges',['../group__BLE__ERROR__SUBRANGES.html',1,'']]],
  ['maximum_20attribute_20lengths',['Maximum attribute lengths',['../group__BLE__GATTS__ATTR__LENS__MAX.html',1,'']]],
  ['module_20specific_20svc_2c_20event_20and_20option_20number_20subranges',['Module specific SVC, event and option number subranges',['../group__ble__ranges.html',1,'']]],
  ['master_20boot_20record_20api',['Master Boot Record API',['../group__nrf__mbr__api.html',1,'']]]
];

#include <stdlib.h>
#include "hardware.h"
#include "door.h"
#include "time.h"
#include "globals.h"
#include "queue.h"

void door_door_timer_start() {
	g_door_timer = time(NULL);
}

int door_door_timer_expired() {
	if ((time(NULL) - g_door_timer) > DOOR_TIMER_BREAK) {
		return 1;
	}
	return 0;
}

int door_door_open() {
	if(hardware_read_obstruction_signal()){
		door_door_timer_start();
	}
	if (door_door_timer_expired() && !hardware_read_obstruction_signal()) {
		hardware_command_door_open(0);
		g_door_timer=0;	
		return 1;
	}
	return 0;
}


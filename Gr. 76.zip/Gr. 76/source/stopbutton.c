#include <stdlib.h>
#include "hardware.h"
#include "door.h"
#include "globals.h"
#include "queue.h"
#include "lights.h"
#include "stopbutton.h"

void stopbutton_stop_button() {
	hardware_command_stop_light(1);
	hardware_command_movement(HARDWARE_MOVEMENT_STOP);
	queue_remove_all_orders();
	lights_clear_all_lights();
	if (globals_check_for_floor()) {
		hardware_command_door_open(1);
	}
}


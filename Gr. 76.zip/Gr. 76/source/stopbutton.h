/** @file
  * @brief Defines how elevator acts when stop button is pressed.
  */

/**
  * @brief Function for stop button behaviour
  */

void stopbutton_stop_button();

#include <stdlib.h>
#include "hardware.h"
#include "lights.h"
#include "globals.h"

void lights_clear_all_lights() {
	for( int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++){
		for (int order_type = 0; order_type < 3; order_type++){
			hardware_command_order_light(floor, order_type,0);
		}
	}
}
	
